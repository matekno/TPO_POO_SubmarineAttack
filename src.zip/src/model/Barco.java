package model;

public class Barco extends ElementoJuego {
	private static final double ANCHO = 120;
	private static final double ALTO = 40;

	private final double anchoMundo;
	private final double velocidad;
	private int sentido; // 1 = hacia la derecha, -1 = hacia la izquierda
	private int pasadasRestantes;

	// Un barco funciona de la siguiente manera:
	// Un barco solo se mueve en el eje X, apoyado sobre la superficie del agua.
	// Tiene algunos parametros random determinados por el NIVEL (ver clase para más
	// detalle): el sentido, la velocidad, y la cantidad de pasadas.
	
	// Su movimiento determinado por avanzar() es ir cambiando su posicion segun
	// sentido y velocidad. Ademas, cuando llega al otro extremo, si le quedan
	// pasadas, invierte el sentido y vuelve a salir pero para el otro lado.

	public Barco(double anchoMundo, boolean desdeIzquierda, double velocidad, int pasadas) {
		super(0, 0, ANCHO, ALTO);
		this.anchoMundo = anchoMundo;
		this.velocidad = velocidad;
		this.pasadasRestantes = pasadas;
		// Arranca justo afuera de la pantalla, del lado que le toco
		if (desdeIzquierda == true) {
			x = -ANCHO / 2;
			sentido = 1;
		} else {
			x = anchoMundo + ANCHO / 2;
			sentido = -1;
		}
	}

	@Override
	public void avanzar(double segundos) {
		x += sentido * velocidad * segundos;
		if (salioDePantalla() == true) {
			pasadasRestantes--;
			sentido = -sentido;
		}
	}

	private boolean salioDePantalla() {
		if (sentido == 1) {
			return x > anchoMundo + ancho / 2;
		}
		return x < -ancho / 2;
	}

	public boolean terminoSusPasadas() {
		return pasadasRestantes == 0;
	}
}